import os
import argparse

def extract_gibbs_energy(filename):
    """从文件中提取吉布斯自由能"""
    if not os.path.exists(filename):
        raise FileNotFoundError(f"文件 {filename} 不存在")

    with open(filename, 'r') as file:
        for line in file:
            if "Sum of electronic and thermal Free Energies=" in line:
                try:
                    return float(line.split('=')[-1].strip())
                except ValueError:
                    raise ValueError(f"无法从文件 {filename} 中解析吉布斯自由能")
    raise ValueError(f"文件 {filename} 中没有找到吉布斯自由能的相关信息")

def calculate_activation_energy(file1, file2, file3):
    """计算反应能垒"""
    try:
        G1 = extract_gibbs_energy(file1)  # 反应物1
        G2 = extract_gibbs_energy(file2)  # 反应物2
        G_transition = extract_gibbs_energy(file3)  # 过渡态

        activation_energy = G_transition - (G1 + G2)
        activation_energy_kcal = activation_energy * 627.51

        return activation_energy_kcal, G1, G2, G_transition

    except ValueError as e:
        print(f"错误: {e}")
        return None, None, None, None

def main():
    parser = argparse.ArgumentParser(description="计算反应的吉布斯自由能和反应能垒")
    parser.add_argument('--reactions', type=int, required=True, help="需要计算的反应数量")
    parser.add_argument('--file1', nargs='+', required=True, help="反应物1的文件路径列表")
    parser.add_argument('--file2', nargs='+', required=True, help="反应物2的文件路径列表")
    parser.add_argument('--file3', nargs='+', required=True, help="过渡态的文件路径列表")

    args = parser.parse_args()

    if len(args.file1) != args.reactions or len(args.file2) != args.reactions or len(args.file3) != args.reactions:
        print("错误: 每个反应应当有对应的三个文件路径")
        return

    for i in range(args.reactions):
        print(f"\n--- 计算第 {i+1} 次反应的能垒 ---")
        
        energy_barrier, G1, G2, G_transition = calculate_activation_energy(args.file1[i], args.file2[i], args.file3[i])

        if energy_barrier is not None:
            print(f"反应能垒为: {energy_barrier:.2f} kcal/mol")
            print(f"反应物1的吉布斯自由能: {G1:.2f}")
            print(f"反应物2的吉布斯自由能: {G2:.2f}")
            print(f"过渡态的吉布斯自由能: {G_transition:.2f}")

            energy_barrier_filename = f"{i+1}_th_energy_barrier.txt"
            with open(energy_barrier_filename, 'w') as f:
                f.write(f"反应能垒: {energy_barrier:.2f} kcal/mol\n")
                f.write(f"反应物1的吉布斯自由能: {G1:.2f}\n")
                f.write(f"反应物2的吉布斯自由能: {G2:.2f}\n")
                f.write(f"过渡态的吉布斯自由能: {G_transition:.2f}\n")
            print(f"反应能垒已保存至 {energy_barrier_filename}")
        else:
            print("计算失败，请检查输入文件内容")

if __name__ == "__main__":
    main()


