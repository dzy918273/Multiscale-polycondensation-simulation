import numpy as np
import pandas as pd
from sys import argv
from XmlBuilder import hoomd_xml

def load_bond_data(xml_file):
    """从XML文件中加载bond信息。

    Args:
        xml_file (str): XML文件的路径。

    Returns:
        np.ndarray: bond信息数组。
    """
    xml = hoomd_xml(xml_file, needed=['bond'])
    return xml.nodes["bond"]

def count_bonds(bond_info, bond_type):
    """统计特定bond类型的数量。

    Args:
        bond_info (np.ndarray): bond信息数组。
        bond_type (str): 需要统计的bond类型。

    Returns:
        int: 该类型bond的数量。
    """
    return np.sum(bond_info[:, 0] == bond_type)

def calculate_conversion_rate(count_a_b, count_a_c, total_reactions):
    """计算转化率。

    Args:
        count_a_b (int): A-B bond的数量。
        count_a_c (int): A-C bond的数量。
        total_reactions (int): 总反应数量。

    Returns:
        float: 转化率。
    """
    return (count_a_b + count_a_c) / total_reactions

def main():
    if len(argv) != 2:
        print("用法: python conversion_rate.py <XML文件路径>")
        return

    # 1. 加载bond信息
    xml_file = argv[1]
    bond_info = load_bond_data(xml_file)

    # 2. 统计A-B和A-C bond的数量
    count_a_b = count_bonds(bond_info, 'A-B')
    count_a_c = count_bonds(bond_info, 'A-C')

    # 3. 打印统计结果
    print("A-B的个数:", count_a_b)
    print("A-C的个数:", count_a_c)

    # 4. 计算转化率
    total_reactions = 20000  # 总反应数量，可以根据实际情况修改
    conversion_rate = calculate_conversion_rate(count_a_b, count_a_c, total_reactions)

    # 5. 打印转化率
    print("转化率:", conversion_rate)

if __name__ == "__main__":
    main()


