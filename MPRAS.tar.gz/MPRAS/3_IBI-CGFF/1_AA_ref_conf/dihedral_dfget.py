import MDAnalysis as mda
from MDAnalysis import transformations
import numpy as np
import pandas as pd
from io import StringIO
import matplotlib.pyplot as plt
from collections import deque
import math
from itertools import chain
import os
import time
import datetime


def calculate_dihedral_angle(p1, p2, p3, p4):
    """
    计算由四个原子坐标定义的二面角。

    参数:
    p1, p2, p3, p4: ndarray，四个原子的坐标

    返回:
    float，计算得到的二面角（单位为弧度）
    """
    b1 = p2 - p1
    b2 = p3 - p2
    b3 = p4 - p3

    # 计算法向量
    n1 = np.cross(b1, b2)
    n2 = np.cross(b2, b3)

    # 归一化
    n1 /= np.linalg.norm(n1)
    n2 /= np.linalg.norm(n2)

    # 计算二面角
    angle = np.arctan2(np.dot(n1, b2) * np.linalg.norm(b2), np.dot(n1, n2))
    return angle


def get_CG_bead_dihedral(universe, frame, N, resgroup, resname):
    """
    获取中心化的二面角数据。

    参数:
    universe: MDAnalysis.Universe，MDAnalysis宇宙对象
    frame: int，当前帧数
    N: int，每个组的原子数量
    resgroup: list，残基组
    resname: list，残基名称

    返回:
    tuple，包含BBAB和ABBA类型二面角的deque对象
    """
    universe.trajectory[frame]
    rescm = [res.center_of_mass(compound='group') for res in resgroup]

    # 使用deque存储二面角
    ABBA = deque()
    BBAB = deque()

    for i in range(len(resgroup) - 3):
        p1 = rescm[i]
        p2 = rescm[i + 1]
        p3 = rescm[i + 2]
        p4 = rescm[i + 3]
        
        n1, n2, n3, n4 = resname[i], resname[i + 1], resname[i + 2], resname[i + 3]
        dihedral_name = f"{n1}-{n2}-{n3}-{n4}"
        
        dihedral = calculate_dihedral_angle(p1, p2, p3, p4)
        
        if (i // N) == ((i + 1) // N) == ((i + 2) // N):
            if dihedral_name in {'B-B-A-B', 'B-A-B-B'}:
                BBAB.append(dihedral)
            else:
                ABBA.append(dihedral)

    return BBAB, ABBA


def calculate_distribution(df):
    """
    计算二面角的频率分布。

    参数:
    df: pandas.Series，包含二面角数据的Series

    返回:
    pandas.DataFrame，包含二面角及其频率的DataFrame
    """
    denominator = len(df)
    frequency = df.value_counts().sort_index()
    normalized_frequency = frequency / denominator
    distribution_df = normalized_frequency.reset_index()
    distribution_df.columns = ['Dihedral', 'Frequency']
    return distribution_df


def main():
    """
    主函数，执行二面角数据的提取和处理。
    """
    # 创建MDAnalysis宇宙对象
    universe = mda.Universe('zzzz-tuihuo-final-eq.tpr', 'zzzz-tuihuo-final-eq.xtc')
    ag = universe.atoms
    transform = transformations.unwrap(ag)
    universe.trajectory.add_transformations(transform)

    # 初始化残基组
    BEAD_A = ["A1", "A2", "A3"]  # 示例
    BEAD_B1 = ["B1", "B2", "B3"]  # 示例
    BEAD_B2 = ["B4", "B5", "B6"]  # 示例
    BEAD_S1 = ["S1", "S2", "S3"]  # 示例
    BEAD_S2 = ["S4", "S5", "S6"]  # 示例

    # 处理残基
    BEAD_B = [item for sublist in zip(BEAD_B1, BEAD_B2) for item in sublist]
    BEAD_S = [item for sublist in zip(BEAD_S1, BEAD_S2) for item in sublist]

    BEAD_ABB = [item for sublist in zip(BEAD_A, BEAD_B1, BEAD_B2) for item in sublist]
    ABB_resname = ['A'] * len(BEAD_A) + ['B'] * (len(BEAD_B1) + len(BEAD_B2))

    abba = deque()
    bbab = deque()
    N = 27  # 每组的原子数量

    time1 = time.time()
    for frame in range(1, len(universe.trajectory), 1):
        ABBA, BBAB = get_CG_bead_dihedral(universe, frame, N, BEAD_ABB, ABB_resname)
        abba.append(ABBA)
        bbab.append(BBAB)
        
        # 输出时间进度
        time2 = time.time()
        spend_time = str(datetime.timedelta(seconds=time2 - time1))
        print(f"Calculating Frame = {frame}  Time Spent = {spend_time}", flush=True)

    # 展平deque
    abba_flat = list(chain.from_iterable(abba))
    bbab_flat = list(chain.from_iterable(bbab))

    # 计算并保存频率分布
    A_B_B_A_distribution = calculate_distribution(pd.Series(abba_flat))
    B_B_A_B_distribution = calculate_distribution(pd.Series(bbab_flat))

    A_B_B_A_distribution.to_csv('ABBA.dat', index=False, header=None, sep=' ')
    B_B_A_B_distribution.to_csv('BBAB.dat', index=False, header=None, sep=' ')

    print("任务完成")


if __name__ == '__main__':
    main()

