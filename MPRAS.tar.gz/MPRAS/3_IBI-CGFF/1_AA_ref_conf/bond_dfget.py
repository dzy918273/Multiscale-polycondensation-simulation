import MDAnalysis as mda
from MDAnalysis import transformations
import numpy as np
import pandas as pd
from io import StringIO
import matplotlib.pyplot as plt
from collections import deque
import math
from itertools import chain
import os
import time
import datetime

def calculate_cg_bondlength_polymer(Universe, frame, N, resgroup, resname):
    """
    计算聚合物的中心基团间的键长
    参数:
        Universe: MDAnalysis的宇宙对象
        frame: 当前帧数
        N: 选择的基团数
        resgroup: 基团的组
        resname: 基团名称
    返回:
        AB: A-B键长的队列
        BB: B-B键长的队列
    """
    u = Universe
    u.trajectory[frame]  # 选定当前帧
    rescm = [res.center_of_mass(compound='group') for res in resgroup]  # 计算每个基团的质心
    AB = deque([])  # A-B 键的距离
    BB = deque([])  # B-B 键的距离

    # 遍历基团以计算键长
    for i in range(len(resgroup) - 1):
        p1 = rescm[i]
        p2 = rescm[i + 1]
        n1 = resname[i]
        n2 = resname[i + 1]
        bond_name = n1 + '-' + n2
        dist = np.sqrt(np.sum(np.square(p2 - p1))) / 10  # 计算距离（转换为合适单位）

        if (i // N) == ((i + 1) // N):  # 检查是否在同一组中
            if bond_name in ['A-B', 'B-A']:
                AB.append(dist)
            else:
                BB.append(dist)

    return AB, BB

def calculate_cg_bondlength_solvent(Universe, frame, resgroup):
    """
    计算溶剂的中心基团间的键长
    参数:
        Universe: MDAnalysis的宇宙对象
        frame: 当前帧数
        resgroup: 基团的组
    返回:
        DF: 溶剂分子的距离数据框
    """
    u = Universe
    u.trajectory[frame]  # 选定当前帧
    rescm = [reses.center_of_mass(compound='group') for reses in resgroup]  # 计算质心
    SS = deque([])

    # 计算相邻基团间的键长
    for i in range(len(rescm) - 1):
        p1 = rescm[i]
        p2 = rescm[i + 1]
        dist = np.sqrt(np.sum(np.square(p2 - p1))) / 10  # 计算距离（转换为合适单位）
        SS.append(dist)

    # 创建数据框以保存频率分布
    data = pd.Series(list(SS))
    Fre = data.value_counts().sort_index()
    denominator = len(data)
    DF = Fre.reset_index()
    DF[0] = DF[0] / denominator
    DF.columns = ['Distance', 'Fre']  # 重命名列
    return DF

def main():
    """
    主函数，执行键长计算并输出结果到文件
    """
    u = mda.Universe('zzzz-tuihuo-final-eq.tpr', 'zzzz-tuihuo-final-eq.xtc')
    ag = u.atoms
    transform = mda.transformations.unwrap(ag)
    u.trajectory.add_transformations(transform)  # 添加变换以处理轨迹

    # 定义基团并分割
    BEAD_A = BEAD_A.split('residue')
    BEAD_B1 = BEAD_B1.split('residue')
    BEAD_B2 = BEAD_B2.split('residue')
    BEAD_S1 = BEAD_S1.split('residue')
    BEAD_S2 = BEAD_S2.split('residue')

    # 合并基团
    BEAD_B = BEAD_B1 + BEAD_B2
    BEAD_S = BEAD_S1 + BEAD_S2

    # 组合基团以形成 ABB 结构
    BEAD_ABB = []
    ABB_resname = []
    for i in range(len(BEAD_B1)):
        BEAD_ABB.append(BEAD_A[i])
        BEAD_ABB.append(BEAD_B1[i])
        BEAD_ABB.append(BEAD_B2[i])
        ABB_resname.extend(['A', 'B', 'B'])

    # 初始化队列以存储结果
    ab = deque([])
    bb = deque([])
    ss = deque([])

    N = 27  # 组的大小

    time1 = time.time()  # 开始计时

    # 遍历轨迹帧以计算键长
    for frame in range(1, len(u.trajectory), 1):
        AB, BB = calculate_cg_bondlength_polymer(u, frame, N, BEAD_ABB, ABB_resname)
        SS = calculate_cg_bondlength_solvent(u, frame, BEAD_S)

        ab.append(AB)
        bb.append(BB)
        ss.append(SS)

        # 计算并输出当前帧的耗时
        time2 = time.time()
        spend_time = time2 - time1
        print(f"Calculating Frame = {frame}  Time Spent = {str(datetime.timedelta(seconds=spend_time))}", flush=True)

    # 将结果展平以便存储
    ab = list(chain.from_iterable(ab))
    bb = list(chain.from_iterable(bb))
    ss = list(chain.from_iterable(ss))

    # 计算并保存结果到文件
    A_B = cal_bond_DF(ab)
    B_B = cal_bond_DF(bb)
    S_S = cal_bond_DF(ss)

    A_B.to_csv('AB.dat', index=0, header=None, sep=' ')
    B_B.to_csv('BB.dat', index=0, header=None, sep=' ')
    S_S.to_csv('SS.dat', index=0, header=None, sep=' ')

    print("Task Finished")

if __name__ == "__main__":
    main()  # 运行主函数


