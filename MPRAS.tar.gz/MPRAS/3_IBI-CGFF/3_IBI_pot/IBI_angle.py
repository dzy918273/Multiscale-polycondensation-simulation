import os
import numpy as np
import pandas as pd
from scipy import constants

# 定义常量
TEMPERATURE = 493  # 温度 (K)
VOLUME_CONVERSION = 0.001  # 体积单位转换 (mL to L)

def remove_first_and_last_line(filename):
    """去除文件的首尾行以清理数据"""
    os.system(f"sed -i '1d' {filename}")
    os.system(f"sed -i '$d' {filename}")

def read_data(log_filename, dat_filename):
    """从日志文件和数据文件中读取数据"""
    x, y = np.loadtxt(log_filename, unpack=True)
    x_ab, y_cg = np.loadtxt(dat_filename, unpack=True)
    return x, y, x_ab, y_cg

def calculate_correction(y, y_cg, correction_factor):
    """根据给定的修正因子计算修正值"""
    r = y_cg / y
    correction = correction_factor * constants.R * TEMPERATURE * np.log(r + 1e-6) * VOLUME_CONVERSION
    return correction

def save_corrected_data(x, y_corrected, output_filename):
    """保存修正后的数据到输出文件"""
    np.savetxt(output_filename, np.c_[x, y_corrected], fmt='%.6f')

def process_file(log_filename, dat_filename, output_filename, correction_factor):
    """
    处理给定的日志文件和数据文件，应用修正并保存结果。
    
    参数：
    log_filename: 日志文件名
    dat_filename: 数据文件名
    output_filename: 输出文件名
    correction_factor: 修正因子
    """
    # 清理日志文件
    remove_first_and_last_line(log_filename)

    # 读取数据
    x, y, x_ab, y_cg = read_data(log_filename, dat_filename)

    # 计算修正值
    correction = calculate_correction(y, y_cg, correction_factor)

    # 应用修正值
    y_corrected = y + correction

    # 保存修正后的数据
    save_corrected_data(x, y_corrected, output_filename)

def main():
    """
    主函数，定义待处理文件的列表，并循环处理每个文件。
    """
    # 文件列表及对应修正因子
    files = [
        ("a-ABX-1.log", "a-ABX-fenbu-CG-s-2000.dat", "a-ABX-2.log", 0.1),
        ("a-ABZ-1.log", "a-ABZ-fenbu-CG-s-2000.dat", "a-ABZ-2.log", 0.3),
        ("a-BXB-1.log", "a-BXB-fenbu-CG-s-2000.dat", "a-BXB-2.log", 0.1),
        ("a-BXY-1.log", "a-BXY-fenbu-CG-s-2000.dat", "a-BXY-2.log", 0.2),
        ("a-BZB-1.log", "a-BZB-fenbu-CG-s-2000.dat", "a-BZB-2.log", 0.5),
        ("a-BZZ-1.log", "a-BZZ-fenbu-CG-s-2000.dat", "a-BZZ-2.log", 0.15),
        ("a-XYX-1.log", "a-XYX-fenbu-CG-s-2000.dat", "a-XYX-2.log", 0.1),
    ]

    # 处理每个文件
    for log_file, dat_file, output_file, correction in files:
        print(f"Processing {log_file} with correction factor {correction}...")
        process_file(log_file, dat_file, output_file, correction)
        print(f"Saved corrected data to {output_file}")

if __name__ == "__main__":
    main()


