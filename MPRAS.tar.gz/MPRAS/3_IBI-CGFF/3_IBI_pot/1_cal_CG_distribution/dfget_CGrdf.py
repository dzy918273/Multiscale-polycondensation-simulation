import MDAnalysis as mda
import numpy as np
import matplotlib.pyplot as plt
import numba
from numba import jit
import math
import time
import datetime

# 计算排除1-3距离的函数
@jit(nopython=True)
def new_cal_dis_exclude_1_3(CM1, CM2, index_g1, index_g2, box):
    """
    计算两个组分中每个珠子的距离，排除同分子中的1-3原子之间的距离。

    参数：
    CM1 : numpy.ndarray
        第一个组分的质心坐标
    CM2 : numpy.ndarray
        第二个组分的质心坐标
    index_g1 : numpy.ndarray
        第一个组分的原子索引
    index_g2 : numpy.ndarray
        第二个组分的原子索引
    box : float
        模拟盒的尺寸

    返回：
    point : numpy.ndarray
        所有计算的距离
    loop : int
        有效距离的数量
    """
    len_mol = 27  # 每个分子的原子数
    point = np.zeros(100000000)  # 用于存储距离的数组
    counter = 0
    
    # 计算CM1和CM2中每个珠子的距离
    for i in range(CM1.shape[0]):
        for j in range(CM2.shape[0]):
            xi, yi, zi = CM1[i]
            xj, yj, zj = CM2[j]
            dx = xi - xj
            dy = yi - yj
            dz = zi - zj
            
            # 考虑周期性边界条件
            dx -= box * np.floor(dx / box + 0.5)
            dy -= box * np.floor(dy / box + 0.5)
            dz -= box * np.floor(dz / box + 0.5)
            
            dis = math.sqrt(dx * dx + dy * dy + dz * dz)
            index_i = index_g1[i]
            index_j = index_g2[j]
            
            # 排除1-3原子之间的距离
            if (index_i // len_mol) == (index_j // len_mol) and abs(index_i - index_j) <= 25:
                dis = 0
            
            point[counter] = dis
            counter += 1
            
    return point, counter

# 粗粒化RDF类
class new_CG_RDF(object):
    def __init__(self, Universe, g1, g2, index_g1, index_g2, binsize):
        """
        初始化RDF计算的参数。

        参数：
        Universe : MDAnalysis.Universe
            MDAnalysis的Universe对象
        g1 : MDAnalysis.Group
            第一个珠子的分子组
        g2 : MDAnalysis.Group
            第二个珠子的分子组
        index_g1 : numpy.ndarray
            第一个组分的原子索引
        index_g2 : numpy.ndarray
            第二个组分的原子索引
        binsize : float
            RDF计算的bin大小
        """
        self.binsize = binsize
        self.u = Universe
        self.g1 = g1
        self.g2 = g2
        self.index_g1 = index_g1
        self.index_g2 = index_g2
        self.volume = 0.0
        self.origin_box = self.u.dimensions[0]
        self.X = np.arange(0.5 * self.binsize, self.origin_box / 2, self.binsize)
        self.rdf_merge = np.zeros(self.X.shape[0] - 1)
        self.time = time.time()
        self.N = 0  # 粒子数量

    def single_frame(self, frame):
        """
        处理单个帧的RDF计算。

        参数：
        frame : int
            当前处理的帧编号
        """
        self.u.trajectory[frame]  # 更新当前帧
        CM1 = self.g1.positions  # 获取珠子g1的位置
        CM2 = self.g2.positions  # 获取珠子g2的位置
        box = self.u.dimensions[0]
        
        # 计算距离并更新RDF
        dis, loop = new_cal_dis_exclude_1_3(CM1, CM2, self.index_g1, self.index_g2, box)
        dis = dis[dis != 0]  # 排除零距离
        
        # 计算直方图
        ids = np.floor(dis / self.binsize).astype(np.int)
        ids = ids[ids < self.X.shape[0] - 1]
        for i in ids:
            self.rdf_merge[i] += 1
            
        self.volume += box ** 3  # 更新体积

        # 打印计算进度
        frame_time = time.time()
        spend_time = frame_time - self.time
        spend_time = str(datetime.timedelta(seconds=spend_time))
        print("计算帧 = %d  用时 = %s" % (frame, spend_time), flush=True)

    def conclude(self, len_frame):
        """
        计算最终的RDF值。

        参数：
        len_frame : int
            总帧数
        """
        shell_vol = self.binsize * 4 * np.pi * (self.X[1:] - 0.5 * self.binsize) ** 2
        box_vol = self.volume / len_frame
        density = self.N / box_vol
        rdf = self.rdf_merge / (density * shell_vol)
        self.rdf = rdf

# 主程序
def main():
    # 初始化MDAnalysis的Universe
    u = mda.Universe('zzzz-tuihuo-final-eq.tpr', 'zzzz-tuihuo-final-eq.xtc')

    # 定义珠子类型
    BEAD_A = BEAD_A.split('residue')
    BEAD_B = BEAD_B.split('residue')
    BEAD_C = BEAD_C.split('residue')
    BEAD_S1 = BEAD_S1.split('residue')
    BEAD_S2 = BEAD_S2.split('residue')

    BEAD_S = []
    for i in range(len(BEAD_S1)):
        BEAD_S.append(BEAD_S1[i])
        BEAD_S.append(BEAD_S2[i])

    # 创建残基名称数组
    resname = np.asarray(list(('ABC' * 360)))
    resname1 = np.asarray(list(('SS' * 1080)))

    # 找到各个类型的珠子的索引
    A_rank = np.argwhere(resname == 'A').ravel()
    B_rank = np.argwhere(resname == 'B').ravel()
    C_rank = np.argwhere(resname == 'C').ravel()
    S_rank = np.argwhere(resname1 == 'S').ravel()

    # 定义计算RDF的函数
    def calculate_rdf(g1, g2, index_g1, index_g2, output_file):
        rdf = new_CG_RDF(u, g1, g2, index_g1, index_g2, 0.1)
        iters = range(1, len(u.trajectory), 1)
        for frame in iters:
            rdf.single_frame(frame)
        rdf.conclude(len(iters))
        np.savetxt(output_file, np.c_[rdf.X[:-1], rdf.rdf], fmt='%.6f')

    # 计算各组分的RDF
    calculate_rdf(BEAD_A, BEAD_A, A_rank, A_rank, 'AA-CG-RDF.dat')
    calculate_rdf(BEAD_A, BEAD_B, A_rank, B_rank, 'AB-CG-RDF.dat')
    calculate_rdf(BEAD_A, BEAD_C, A_rank, C_rank, 'AC-CG-RDF.dat')
    calculate_rdf(BEAD_B, BEAD_B, B_rank, B_rank, 'BB-CG-RDF.dat')
    calculate_rdf(BEAD_B, BEAD_C, B_rank, C_rank, 'BC-CG-RDF.dat')
    calculate_rdf(BEAD_C, BEAD_C, C_rank, C_rank, 'CC-CG-RDF.dat')
    calculate_rdf(BEAD_S, BEAD_A, S_rank, A_rank, 'SA-CG-RDF.dat')
    calculate_rdf(BEAD_S, BEAD_B, S_rank, B_rank, 'SB-CG-RDF.dat')
    calculate_rdf(BEAD_S, BEAD_C, S_rank, C_rank, 'SC-CG-RDF.dat')

    print("粗粒化RDF计算完成！")

if __name__ == "__main__":
    main()


