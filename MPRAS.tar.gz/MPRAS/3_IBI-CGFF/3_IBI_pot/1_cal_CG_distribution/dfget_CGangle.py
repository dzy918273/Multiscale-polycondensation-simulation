import numpy as np
import pandas as pd
import time
import datetime
import matplotlib.pyplot as plt
from itertools import chain
from io import StringIO
from xml.etree import cElementTree
import sys

sys.dont_write_bytecode = True

class HOOMDXML:
    """
    该类用于解析HOOMD XML文件并提取指定的属性。
    
    用法：
        xml = HOOMDXML("particle000.xml", ["position", "angle"])  # 提供需要的属性
        box = xml.box  # 获取盒子尺寸
    """
    
    @staticmethod
    def _get_attrib(dd):
        """将字典转换为NumPy结构化数组。"""
        dtype = eval('[' + ','.join([f"('{key}', int)" for key in dd.keys()]) + ']')
        values = [tuple(dd.values())]
        return np.array(values, dtype=dtype)

    def __init__(self, filename, needed=[]):
        """初始化，解析XML文件并提取所需的节点数据。"""
        tree = cElementTree.ElementTree(file=filename)
        root = tree.getroot()
        configuration = root[0]
        self.configure = self._get_attrib(configuration.attrib)
        self.nodes = {}
        
        # 提取box信息和所需的节点数据
        for e in configuration:
            if e.tag == 'box':
                self.box = np.array([float(e.attrib['lx']), float(e.attrib['ly']), float(e.attrib['lz'])])
                continue
            if (len(needed) != 0) and (e.tag not in needed):
                continue
            self.nodes[e.tag] = pd.read_csv(StringIO(e.text), delim_whitespace=True, squeeze=1, header=None).values

def calculate_angle(p1, p2, p3):
    """计算由三个点形成的角度（以度为单位）。"""
    vec1 = p2 - p1
    vec2 = p2 - p3
    norm_vec1 = vec1 / np.linalg.norm(vec1)
    norm_vec2 = vec2 / np.linalg.norm(vec2)
    cos_angle = np.dot(norm_vec1, norm_vec2)
    angle = np.arccos(cos_angle) * (180.0 / np.pi)
    return angle

def calculate_angles(xml_name, angle_infos):
    """根据角度信息计算角度，并分类存储。"""
    ABB = []
    BAB = []
    
    xml = HOOMDXML(xml_name, ["position", "image"])
    position = xml.nodes['position'] + xml.nodes['image'] * xml.box
    
    for angle_info in angle_infos:
        angle_name, i, j, k = angle_info
        p1 = position[i]
        p2 = position[j]
        p3 = position[k]
        angle = calculate_angle(p1, p2, p3)
        
        if angle_name in ['A-B-C', 'A-C-B']:
            ABB.append(angle)
        elif angle_name == 'B-A-C':
            BAB.append(angle)
    
    return ABB, BAB

def calculate_angle_distribution(angle_list):
    """计算角度分布及其频率。"""
    angle_series = pd.Series(angle_list)
    frequency = angle_series.value_counts().sort_index()
    distribution = frequency / len(angle_series)
    df_distribution = distribution.reset_index()
    df_distribution.columns = ['Angle', 'Frequency']
    return df_distribution

def main():
    """主函数，用于执行角度计算和分布分析。"""
    # 获取输入的XML文件路径
    xml_files = sys.argv[1:]
    ABB_all = []
    BAB_all = []
    
    start_time = time.time()
    
    for file in xml_files:
        angle_infos = [...]  # 这里填入实际的角度信息，格式为[(angle_name, i, j, k), ...]
        abb, bab = calculate_angles(file, angle_infos)
        
        ABB_all.append(abb)
        BAB_all.append(bab)
        
        elapsed_time = time.time() - start_time
        print(f"处理文件: {file}，用时: {str(datetime.timedelta(seconds=elapsed_time))}")

    # 计算全局角度分布
    ABB_distribution = calculate_angle_distribution(list(chain.from_iterable(ABB_all)))
    BAB_distribution = calculate_angle_distribution(list(chain.from_iterable(BAB_all)))
    
    # 将结果保存到文件
    ABB_distribution.to_csv('CG_ABB.dat', index=False, header=None, sep=' ')
    BAB_distribution.to_csv('CG_BAB.dat', index=False, header=None, sep=' ')

if __name__ == "__main__":
    main()


