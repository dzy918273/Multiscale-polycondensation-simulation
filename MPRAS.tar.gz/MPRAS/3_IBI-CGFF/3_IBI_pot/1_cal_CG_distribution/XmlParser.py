import re
from io import StringIO
from xml.etree import cElementTree
import numpy as np


def control_in(control_file):
    """
    控制输入文件的读取和处理（功能待实现）。

    参数:
    control_file: str，控制文件的路径
    """
    pass


class Box:
    """
    表示模拟盒子的类，包括其三维属性。
    """

    def __init__(self):
        self.xy = 0
        self.xz = 0
        self.yz = 0

    def update(self, attributes):
        """
        更新盒子的属性。

        参数:
        attributes: dict，包含新的盒子属性
        """
        self.__dict__.update(attributes)


class XmlParser:
    """
    从XML文件中解析模拟参数的类。
    """

    def __init__(self, filename, needed=None):
        """
        初始化XmlParser类，解析给定的XML文件。

        参数:
        filename: str，XML文件的路径
        needed: list，可选，指定需要解析的元素
        """
        # 解析XML文件
        tree = cElementTree.ElementTree(file=filename)
        root = tree.getroot()
        
        self.box = Box()  # 初始化Box对象
        self.data = {}    # 存储解析的数据
        needed = [] if needed is None else needed
        
        # 解析根元素的属性
        for key in root[0].attrib:
            self.__dict__[key] = int(root[0].attrib[key])
        
        # 解析XML文件的各个子元素
        for element in root[0]:
            self._parse_element(element, needed)

    def _parse_element(self, element, needed):
        """
        解析XML元素，并将其存储在类的属性中。

        参数:
        element: Element，XML元素
        needed: list，指定需要解析的元素
        """
        if element.tag == 'box':
            self.box.update(element.attrib)  # 更新盒子属性
        elif len(needed) > 0 and element.tag not in needed:
            return  # 如果该元素不在需要解析的列表中，跳过
        elif element.tag == 'reaction':
            self.data['reaction'] = self._parse_reaction(element.text)
        elif element.tag == 'template':
            self.data['template'] = eval('{%s}' % element.text)  # 将模板解析为字典
        elif len(element.text.strip()) > 1:
            self.data[element.tag] = self._parse_data(element.text)

    def _parse_reaction(self, text):
        """
        解析反应元素的文本。

        参数:
        text: str，反应元素的文本内容

        返回:
        list，解析后的反应列表
        """
        reaction_list = text.strip().split('\n')
        reaction_list = [l for l in reaction_list if l]  # 去除空行
        parsed_reactions = []
        for line in reaction_list:
            parts = re.split(r'\s+', line)
            parts = [int(p) if i > 0 else p for i, p in enumerate(parts) if p]  # 转换为整数
            parsed_reactions.append(parts)
        return parsed_reactions

    def _parse_data(self, text):
        """
        解析数据元素的文本。

        参数:
        text: str，数据元素的文本内容

        返回:
        numpy.ndarray，解析后的数据
        """
        return np.genfromtxt(StringIO(text), dtype=None, encoding=None)


if __name__ == '__main__':
    # 示例用法：创建XmlParser实例并解析XML文件
    parser = XmlParser('example.xml', needed=['box', 'reaction', 'template'])
    print("Box properties:", parser.box.__dict__)
    print("Parsed data:", parser.data)


