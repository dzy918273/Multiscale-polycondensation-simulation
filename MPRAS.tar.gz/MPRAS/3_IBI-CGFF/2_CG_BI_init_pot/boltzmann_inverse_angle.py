import my_script as ms
import numpy as np
import matplotlib.pyplot as plt
from sys import argv

# 从命令行参数获取数据文件名
data = ms.Boltzmann_inverse_angle(argv[1])

# 绘制角度的Boltzmann反演结果
plot = plt.figure()
plt.plot(data[0], data[1])
plt.show()

# 将结果保存到指定的CSV文件
data.to_csv(argv[2], header=None, index=None, sep=' ')
