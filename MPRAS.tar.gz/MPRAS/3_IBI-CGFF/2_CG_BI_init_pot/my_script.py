import MDAnalysis as mda
from MDAnalysis import transformations
import numpy as np
import pandas as pd
from io import StringIO
import matplotlib.pyplot as plt
from collections import deque
import math

def get_CG_bead_bondlength(Universe, frame, identitor, res):
    u = Universe
    u.trajectory[frame]
    rescm = [reses.center_of_mass(compound = 'group') for reses in res]
    DD = deque([])
    LL = deque([])
    DL = deque([])
    for i in range(len(rescm)-1):
        if i != len(rescm)-1:
            p1 = rescm[i]
            p2 = rescm[i+1]
            r1 = res[i].resnames[0]
            r2 = res[i+1].resnames[0]
            if identitor[i].fragment != identitor[i+1].fragment:
                continue
            dist = np.sqrt(np.sum(np.square(p2-p1)))/10
            if r1 == 'MMH':
                r1 = 'MMD'
            if r2 == 'MMT':
                r2 = 'MML'
            if r1 != r2 :
                DL.append(dist)
            else:
                if r1 == 'MMD':
                    DD.append(dist)
                else:
                    LL.append(dist)


    return DD, LL, DL

def cal_angle(p1,p2,p3):
    a = p1
    b = p2
    c = p3
    f = b-a
    e = b-c
    abVec = np.linalg.norm(f)
    bcVec = np.linalg.norm(e)
    abNorm = f / abVec;
    bcNorm = e / bcVec;
    res = abNorm[0] * bcNorm[0] + abNorm[1] * bcNorm[1] + abNorm[2] * bcNorm[2];
    angle = np.arccos(res)*180.0/ np.pi
    return angle

def cal_dihedral(p1,p2,p3,p4):
    p = [p1,p2,p3,p4]
    p = np.array(p)
    b = p[:-1] - p[1:]
    b[0] *= -1
    v = np.array( [ v - (v.dot(b[1])/b[1].dot(b[1])) * b[1] for v in [b[0], b[2]] ] )
    # Normalize vectors
    v /= np.sqrt(np.einsum('...i,...i', v, v)).reshape(-1,1)
    b1 = b[1] / np.linalg.norm(b[1])
    x = np.dot(v[0], v[1])
    m = np.cross(v[0], b1)
    y = np.dot(m, v[1])
    return np.degrees(np.arctan2( y, x ))

def get_CG_bead_angle(Universe, frame, identitor, res):
    u = Universe
    u.trajectory[frame]
    rescm = [reses.center_of_mass(compound = 'group') for reses in res]
    DDD = deque([])
    DDL = deque([])
    DLD = deque([])
    LLL=  deque([])
    LLD = deque([])
    LDL = deque([])

    for i in range(len(rescm)-2):
        if i != len(rescm)-2:
            p1 = rescm[i]
            p2 = rescm[i+1]
            p3 = rescm[i+2]
            angle = cal_angle(p1, p2, p3)
            r1 = res[i].resnames[0]
            r2 = res[i+1].resnames[0]
            r3 = res[i+2].resnames[0]
            if identitor[i].fragment != identitor[i+1].fragment or identitor[i+1].fragment != identitor[i+2].fragment:
                continue
            if r1 == 'MMH':
                r1 = 'MMD'
            if r3 == 'MMT':
                r3 = 'MML'
            if r1 == r2 == r3:
                if r1 == 'MMD':
                    DDD.append(angle)
                else:
                    LLL.append(angle)
            else:
                if [r1, r2, r3].count('MMD') == 2:
                    if r2 == 'MML':
                        DLD.append(angle)
                    else:
                        DDL.append(angle)
                else:
                    if r2 == 'MMD':
                        LDL.append(angle)
                    else:
                        LLD.append(angle)
    
    return DDD, DDL, DLD, LLL, LLD, LDL

def get_CG_bead_dihedral(Universe, frame, identitor, res):
    u = Universe
    u.trajectory[frame]
    rescm = [reses.center_of_mass(compound = 'group') for reses in res]
    AAAA = deque([])
    AAAB = deque([])
    ABBB = deque([])
    AABA = deque([])
    ABAA = deque([])
    AABB = deque([])
    ABAB = deque([])
    ABBA = deque([])

    for i in range(len(rescm)-3):
        p1 = rescm[i]
        p2 = rescm[i+1]
        p3 = rescm[i+2]
        p4 = rescm[i+3]
        dihedral = cal_dihedral(p1, p2, p3, p4)
        r1 = res[i].resnames[0]
        r2 = res[i+1].resnames[0]
        r3 = res[i+2].resnames[0]
        r4 = res[i+3].resnames[0]
        m1 = identitor[i].fragment
        m2 = identitor[i+1].fragment
        m3 = identitor[i+2].fragment
        m4 = identitor[i+3].fragment
        if not(m1 == m2 == m3 == m4): 
            continue
        if r1 == 'MMH':
            r1 = 'MMD'
        if r3 == 'MMT':
            r3 = 'MML'
        seq = r1+'-'+r2+'-'+r3+'-'+r4
        if seq == 'MMD-MMD-MMD-MMD' or seq == 'MML-MML-MML-MML':
            AAAA.append(dihedral)
        if seq == 'MMD-MMD-MMD-MML' or seq == 'MML-MML-MML-MMD':
            AAAB.append(dihedral)
        if seq == 'MMD-MML-MML-MML' or seq == 'MML-MMD-MMD-MMD':
            ABBB.append(dihedral)
        if seq == 'MMD-MMD-MML-MMD' or seq == 'MML-MML-MMD-MML':
            AABA.append(dihedral)
        if seq == 'MMD-MML-MMD-MMD' or seq == 'MML-MMD-MML-MML':
            ABAA.append(dihedral)
        if seq == 'MMD-MMD-MML-MML' or seq == 'MML-MML-MMD-MMD':
            AABB.append(dihedral)
        if seq == 'MMD-MML-MMD-MML' or seq == 'MML-MMD-MML-MMD':
            ABAB.append(dihedral)
        if seq == 'MMD-MML-MML-MMD' or seq == 'MML-MMD-MMD-MML':
            ABBA.append(dihedral)
    return AAAA,AAAB,ABBB,AABA,ABAA,AABB,ABAB,ABBA


def cal_bond_DF(distr):
    bb = ''
    for i,j in enumerate(distr):
        if i < len(distr)-1:
            bb += ('%.3f\n' % j)
        else:
            bb += ('%.3f' % j)

    data = pd.read_csv(StringIO(bb), header=None, float_precision='round_trip')
    data = data[data[0]<1]
    denominator = len(data[0])
    Data = pd.Series(data[0])
    Fre = Data.value_counts()
    Fre_sort = Fre.sort_index(axis=0,ascending=True)
    DF = Fre_sort.reset_index()
    DF[0] = DF[0]/denominator
    DF.columns = ['Distance','Fre']
    return DF

def half(x):
    return round(x*2)/2

def cal_angle_DF(angle):
    aa = ''
    for i,j in enumerate(angle):
        if i < len(angle)-1:
            aa += ('%d\n' % round(j))
        else:
            aa += ('%d' % round(j))

    data = pd.read_csv(StringIO(aa), header=None, float_precision='round_trip')

    denominator = len(data[0])
    Data = pd.Series(data[0])
    Fre = Data.value_counts()
    Fre_sort = Fre.sort_index(axis=0,ascending=True)
    DF = Fre_sort.reset_index()
    DF[0] = DF[0]/denominator
    DF.columns = ['Angle','Fre']
    return DF

def triple_round(x):
    return round(x/10)*10

def cal_dihedral_DF(dihedral):
    aa = ''
    for i,j in enumerate(dihedral):
        if i < len(dihedral)-1:
            aa += ('%d\n' % triple_round(j))
        else:
            aa += ('%d' % triple_round(j))

    data = pd.read_csv(StringIO(aa), header=None, float_precision='round_trip')

    denominator = len(data[0])
    Data = pd.Series(data[0])
    Fre = Data.value_counts()
    Fre_sort = Fre.sort_index(axis=0,ascending=True)
    DF = Fre_sort.reset_index()
    DF[0] = DF[0]/denominator
    DF.columns = ['Dihedral','Fre']
    return DF

def plot_bond_DF(DF, bondtype):
    plot=plt.figure()
    ax1=plot.add_subplot(1,1,1)
    ax1.plot(DF['Distance'],DF['Fre'])
    ax1.set_title("%s bondlength distribution" % bondtype)
    ax1.set_xlabel("bondlength")
    ax1.set_ylabel("P")
    ax1.set_xlim(1, 5)
    ax1.set_ylim(0, 0.2)
    plt.show()

def plot_angle_DF(DF,angletype):
    plot=plt.figure()
    ax1=plot.add_subplot(1,1,1)
    ax1.plot(DF['Angle'],DF['Fre'])
    ax1.set_title("%s angle distribution" % angletype)
    ax1.set_xlabel("angle")
    ax1.set_ylabel("P")
    ax1.set_xlim(90, 150)
    ax1.set_ylim(0, 0.2)
    plt.show()

import time
import datetime
class non_exclude_RDF(object):
    def __init__(self, Universe, g1, g2, binsize):
        self.g1 = g1
        self.g2 = g2
        self.G1 = self.g1.split('residue')
        self.G2 = self.g2.split('residue')
        self.binsize = binsize
        self.u = Universe
        self.volume = 0.0
        self.origin_box = self.u.dimensions[0]
        self.X = np.arange(0.5*self.binsize,self.origin_box/2, self.binsize)
        self.rdf_merge = np.zeros(self.X.shape[0]-1)
        self.time = time.time()
        print(self.g1)
    @staticmethod
    def pbc(_a, _box):
        return _a - _box * np.round(_a/_box)
    
    def single_frame(self, frame):
        self.u.trajectory[frame]
        self.box = self.u.dimensions[0]
        CM1 = []
        for res in self.G1:
            CM1.append(res.center_of_mass(compound='group', unwrap = True))
        CM1 = np.array(CM1).astype('float64')
        CM2 = []
        for res in self.G2:
            CM2.append(res.center_of_mass(compound='group', unwrap = True))
        CM2 = np.array(CM2).astype('float64')
        for i, cm in enumerate(CM1):
            distance = np.linalg.norm(self.pbc(CM2-cm, self.box), axis=-1).ravel()
            distance = distance[distance != 0]
            ids = np.floor(distance/self.binsize).astype(np.int)
            ids = ids[ids<self.X.shape[0]-1]
            for j in ids:
                self.rdf_merge[j]  += 1
        self.volume += self.box**3
        frame_time = time.time()
        spend_time = frame_time - self.time
        spend_time = str(datetime.timedelta(seconds = spend_time))
        print("Calculating Frame = %d  Time Spent = %s" % (frame, spend_time), flush = True)

    def conclude(self,len_frame):
        nA = len(self.G1)
        nB = len(self.G2)
        if self.G1 == self.G2:
            N = nA * (nB-1)
        else:
            N = nA * nB
        shell_vol = self.binsize * 4 * np.pi * (self.X[1:]-0.5*self.binsize)**2
        box_vol = self.volume / len_frame
        density = N / box_vol
        rdf = self.rdf_merge / (density * shell_vol * len_frame)
        self.rdf = rdf

import numba
from numba import jit
import math
@jit(nopython = True)
def cal_dis_exclude_1_3(rescm, resname, box):
    len_mol = 20
    loop_DD = 0
    loop_DL = 0
    loop_LL = 0
    point_DD = np.zeros(1500000)
    point_DL = np.zeros(1500000)
    point_LL = np.zeros(1500000)
    counter = 0
    for i in range(rescm.shape[0]):
        for j in range(rescm.shape[0]):
            xi, yi, zi = rescm[i,0], rescm[i,1], rescm[i,2]
            xj, yj, zj = rescm[j,0], rescm[j,1], rescm[j,2]
            dx = xi - xj
            dy = yi - yj
            dz = zi - zj
            dx -= box * math.floor(dx/box+0.5) 
            dy -= box * math.floor(dy/box+0.5)
            dz -= box * math.floor(dz/box+0.5)
            dis = math.sqrt(dx * dx + dy * dy + dz * dz)
            if (i // len_mol) == (j // len_mol):
                if abs(i-j) <= 0:
                    dis = 0
                else:
                    pass
            else:
                pass
            r1 = resname[i] 
            r2 = resname[j] 
            if r1 == r2:
                if r1 == 'MMD':
                    point_DD[counter] = dis
                    loop_DD += 1
                    if dis == 0:
                        loop_DD -= 1
                else:
                    point_LL[counter] = dis
                    loop_LL += 1
                    if dis == 0:
                        loop_LL -= 1
            else:
                point_DL[counter] = dis
                loop_DL += 1
                if dis == 0:
                    loop_DL -= 1
            counter += 1
    return point_DD, point_DL, point_LL, loop_DD, loop_DL, loop_LL

import time
import datetime
class RDF(object):
    def __init__(self, Universe, binsize):
        self.binsize = binsize
        self.u = Universe
        self.resname = np.array([residue.resnames[0]  for residue in self.u.atoms.split('residue')]) 
        H = np.argwhere(self.resname=='MMH').ravel()
        for i in H:
            self.resname[i] = 'MMD'
        T = np.argwhere(self.resname=='MMT').ravel()
        for j in T:
            self.resname[j] = 'MML'
        self.volume = 0.0
        self.origin_box = self.u.dimensions[0]
        self.X = np.arange(0.5*self.binsize,self.origin_box/2, self.binsize)
        self.rdf_merge_DD = np.zeros(self.X.shape[0]-1)
        self.rdf_merge_DL = np.zeros(self.X.shape[0]-1)
        self.rdf_merge_LL = np.zeros(self.X.shape[0]-1)
        self.time = time.time()
        self.identitor = self.u.select_atoms('name C04') 
        self.N_DD = 0
        self.N_DL = 0
        self.N_LL = 0
    @staticmethod
    def pbc(_a, _box):
        return _a - _box * np.round(_a/_box)

    def single_frame(self, frame):
        self.u.trajectory[frame]
        self.box = self.u.dimensions[0]
        rescm = self.u.atoms.center_of_mass(compound = 'residues', unwrap = True)
        dis_DD, dis_DL, dis_LL, loop_DD, loop_DL, loop_LL = cal_dis_exclude_1_3(rescm, self.resname, self.box)
        self.N_DD += loop_DD
        self.N_DL += loop_DL
        self.N_LL += loop_LL
        dis_DD, dis_DL, dis_LL= dis_DD[dis_DD != 0], dis_DL[dis_DL != 0], dis_LL[dis_LL != 0] 
        ids_DD = np.floor(dis_DD/self.binsize).astype(np.int)
        ids_DL = np.floor(dis_DL/self.binsize).astype(np.int)
        ids_LL = np.floor(dis_LL/self.binsize).astype(np.int)
        ids_DD = ids_DD[ids_DD<self.X.shape[0]-1]
        ids_DL = ids_DL[ids_DL<self.X.shape[0]-1]
        ids_LL = ids_LL[ids_LL<self.X.shape[0]-1]
        for i in ids_DD:
            self.rdf_merge_DD[i]  += 1
        for i in ids_DL:
            self.rdf_merge_DL[i]  += 1
        for i in ids_LL:
            self.rdf_merge_LL[i]  += 1
        self.volume += self.box**3
        frame_time = time.time()
        spend_time = frame_time - self.time
        spend_time = str(datetime.timedelta(seconds = spend_time))
        print("Calculating Frame = %d  Time Spent = %s" % (frame, spend_time), flush = True)

    def conclude(self,len_frame):
        shell_vol = np.power(self.X[1:], 3) - np.power(self.X[:-1], 3)
        shell_vol *= 4/3.0 * np.pi
        box_vol = self.volume / len_frame
        DD_density = self.N_DD / box_vol
        DL_density = self.N_DL / box_vol
        LL_density = self.N_LL / box_vol
        rdf_DD = self.rdf_merge_DD / (DD_density * shell_vol)
        rdf_DL = self.rdf_merge_DL / (DL_density * shell_vol)
        rdf_LL = self.rdf_merge_LL / (LL_density * shell_vol)
        rdf = np.vstack((rdf_DD, rdf_DL))
        rdf = np.vstack((rdf, rdf_LL))
        self.rdf = rdf
 


from scipy import constants
import os.path
def Boltzmann_inverse_bond(filename):   ##unit:kJ/(mol*nm2)
    data = pd.read_csv(filename,delim_whitespace = True, header = None, float_precision='round_trip')
    data[1] = -constants.R * 583 * np.log(data[1]/(data[0])**2) * 0.001
    return data

def Boltzmann_inverse_angle(filename):   
    data = pd.read_csv(filename,delim_whitespace = True, header = None, float_precision='round_trip')
    a = data[0] * np.pi / 180
    data[1] = -constants.R * 583 * np.log(data[1]/(np.sin(a))) * 0.001
    return data

def Boltzmann_inverse_dihedral(filename):
    data = pd.read_csv(filename,delim_whitespace = True, header = None, float_precision='round_trip')
    a = data[0] * np.pi / 180
    data[1] = -constants.R * 583 * np.log(data[1]) * 0.001
    return data



def Boltzmann_inverse_nonbond(filename):
    data = pd.read_csv(filename,delim_whitespace = True, header = None, float_precision='round_trip')
    data[1] = -constants.R * 583 * np.log(data[1]) * 0.001
    return data

@jit(nopython = True)
def cal_backbone_dis_exclude_1_3(rescm, box):
    len_mol = 40
    loop = 0
    point = np.zeros(10000000)
    counter = 0
    for i in range(rescm.shape[0]-1):
        for j in range(i+1, rescm.shape[0]):
            xi, yi, zi = rescm[i,0], rescm[i,1], rescm[i,2]
            xj, yj, zj = rescm[j,0], rescm[j,1], rescm[j,2]
            dx = xi - xj
            dy = yi - yj
            dz = zi - zj
            dx -= box * math.floor(dx/box+0.5) 
            dy -= box * math.floor(dy/box+0.5)
            dz -= box * math.floor(dz/box+0.5)
            dis = math.sqrt(dx * dx + dy * dy + dz * dz)
            if (i // len_mol) == (j // len_mol):
                if abs(i-j) <= 2:
                    dis = 0
                else:
                    pass
            else:
                pass
            point[counter] = dis
            loop += 1
            if dis == 0:
                loop -= 1
            counter += 1
    return point, loop

import time
import datetime
class RDF_backbone(object):
    def __init__(self, Universe, binsize):
        self.binsize = binsize
        self.u = Universe
        A =self.u.select_atoms('resname MMH and name C04')
        B =self.u.select_atoms('resname MMH and name C05')
        C =self.u.select_atoms('resname MMD and name C04')
        D =self.u.select_atoms('resname MMD and name C05')
        E =self.u.select_atoms('resname MML and name C04')
        F =self.u.select_atoms('resname MML and name C06')
        G =self.u.select_atoms('resname MMT and name C05')
        H =self.u.select_atoms('resname MMT and name C06')
        self.SS = A|B|C|D|E|F|G|H

        self.volume = 0.0
        self.origin_box = self.u.dimensions[0]
        self.X = np.arange(0.5*self.binsize,self.origin_box/2, self.binsize)
        self.rdf_merge = np.zeros(self.X.shape[0]-1)
        self.time = time.time()
        self.N = 0
    @staticmethod
    def pbc(_a, _box):
        return _a - _box * np.round(_a/_box)

    def single_frame(self, frame):
        self.u.trajectory[frame]
        self.box = self.u.dimensions[0]
        pos = self.SS.positions
        dis, loop = cal_backbone_dis_exclude_1_3(pos, self.box)
        self.N += loop
        dis= dis[dis != 0]
        ids = np.floor(dis/self.binsize).astype(np.int)
        ids = ids[ids<self.X.shape[0]-1]
        for i in ids:
            self.rdf_merge[i]  += 1
        self.volume += self.box**3
        frame_time = time.time()
        spend_time = frame_time - self.time
        spend_time = str(datetime.timedelta(seconds = spend_time))
        print("Calculating Frame = %d  Time Spent = %s" % (frame, spend_time), flush = True)

    def conclude(self,len_frame):
        shell_vol = self.binsize * 4 * np.pi * (self.X[1:]-0.5*self.binsize)**2
        box_vol = self.volume / len_frame
        density = self.N / box_vol
        rdf = self.rdf_merge / (density * shell_vol)
        self.rdf = rdf


@jit(nopython = True)
def new_cal_dis_exclude_1_3(CM1,CM2,index_g1,index_g2, box):
    len_mol = 40
    loop = 0
    point = np.zeros(10000000)
    counter = 0
    for i in range(CM1.shape[0]):
        for j in range(CM2.shape[0]):
            xi, yi, zi = CM1[i,0], CM1[i,1], CM1[i,2]
            xj, yj, zj = CM2[j,0], CM2[j,1], CM2[j,2]
            dx = xi - xj
            dy = yi - yj
            dz = zi - zj
            dx -= box * math.floor(dx/box+0.5) 
            dy -= box * math.floor(dy/box+0.5)
            dz -= box * math.floor(dz/box+0.5)
            dis = math.sqrt(dx * dx + dy * dy + dz * dz)
            index_i = index_g1[i]
            index_j = index_g2[j]
            if (index_i // len_mol) == (index_j // len_mol):
                if abs(index_i-index_j) <= 3:
                    dis = 0
                else:
                    pass
            else:
                pass
            point[counter] = dis
            loop += 1
            if dis == 0:
                loop -= 1
            counter += 1
    return point, loop

import time
import datetime
class new_RDF(object):
    def __init__(self, Universe,g1,g2,index_g1,index_g2, binsize):
        self.binsize = binsize
        self.u = Universe
        self.g1 = g1
        self.g2 = g2
        self.G1 = self.g1.split('residue')
        self.G2 = self.g2.split('residue')
        self.index_g1 = index_g1
        self.index_g2 = index_g2
        self.volume = 0.0
        self.origin_box = self.u.dimensions[0]
        self.X = np.arange(0.5*self.binsize,self.origin_box/2, self.binsize)
        self.rdf_merge = np.zeros(self.X.shape[0]-1)
        self.time = time.time()
        self.N = 0
    @staticmethod
    def pbc(_a, _box):
        return _a - _box * np.round(_a/_box)

    def single_frame(self, frame):
        self.u.trajectory[frame]
        self.box = self.u.dimensions[0]
        CM1 = []
        for res in self.G1:
            CM1.append(res.center_of_mass(compound='group', unwrap = True))
        CM1 = np.array(CM1).astype('float64')
        CM2 = []
        for res in self.G2:
            CM2.append(res.center_of_mass(compound='group', unwrap = True))
        CM2 = np.array(CM2).astype('float64')
        dis, loop = new_cal_dis_exclude_1_3(CM1,CM2,self.index_g1,self.index_g2, self.box)
        self.N += loop
        dis= dis[dis != 0]
        ids = np.floor(dis/self.binsize).astype(np.int)
        ids = ids[ids<self.X.shape[0]-1]
        for i in ids:
            self.rdf_merge[i]  += 1
        self.volume += self.box**3
        frame_time = time.time()
        spend_time = frame_time - self.time
        spend_time = str(datetime.timedelta(seconds = spend_time))
        print("Calculating Frame = %d  Time Spent = %s" % (frame, spend_time), flush = True)
    def conclude(self,len_frame):
        shell_vol = self.binsize * 4 * np.pi * (self.X[1:]-0.5*self.binsize)**2
        box_vol = self.volume / len_frame
        density = self.N / box_vol
        rdf = self.rdf_merge / (density * shell_vol)
        self.rdf = rdf
