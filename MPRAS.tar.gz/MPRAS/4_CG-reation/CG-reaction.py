#!/usr/bin/python
from hoomd_script import *
from sys import argv
s = init.read_xml(filename='r-nvt-60ns.0040000000.xml', time_step=0)

o = s.take_snapshot(all = True)

# force field setup
import os

# 力场文件路径和对应关系的字典
non_bond_potentials = {
    ('A', 'A'): 'nb-AA.log',
    ('A', 'B'): 'nb-AB.log',
    ('A', 'C'): 'nb-AB.log',
    ('B', 'B'): 'nb-BB.log',
    ('B', 'C'): 'nb-BB.log',
    ('C', 'C'): 'nb-BB.log',
    ('S', 'A'): 'nb-SA.log',
    ('S', 'B'): 'nb-SB.log',
    ('S', 'C'): 'nb-SB.log',
    ('S', 'S'): 'nb-SS.log'
}

bond_potentials = {
    ('A-B'): 'b-AB-1-CG.log',
    ('B-C'): 'b-BC-1-CG.log',
    ('A-C'): 'b-AB-1-CG.log',
    ('S-S'): 'b-SS-1-CG.log'
}

angle_potentials = {
    ('A-B-C'): 'a-ABC-1-new-CG.log',
    ('A-C-B'): 'a-ABC-1-new-CG.log',
    ('B-A-C'): 'a-CAB-1-new-CG.log',
    ('B-A-B'): 'a-CAB-1-new-CG.log',
    ('C-A-C'): 'a-CAB-1-new-CG.log',
    ('C-A-B'): 'a-CAB-1-new-CG.log'
}

dihedral_potentials = {
    ('A-B-C-A'): 'd-ABBA-1-CG.log',
    ('A-C-B-A'): 'd-ABBA-1-CG.log',
    ('B-A-C-B'): 'd-BBAB-1-CG.log',
    ('B-A-B-C'): 'd-BBAB-1-CG.log',
    ('B-C-A-C'): 'd-BBAB-1-CG.log',
    ('B-C-A-B'): 'd-BBAB-1-CG.log',
    ('C-B-A-C'): 'd-BBAB-1-CG.log',
    ('C-A-B-C'): 'd-BBAB-1-CG.log',
    ('C-A-C-B'): 'd-BBAB-1-CG.log',
    ('C-B-A-B'): 'd-BBAB-1-CG.log'
}

# 加载非键作用势能
table = pair.table(width=2000)
for (type1, type2), filename in non_bond_potentials.items():
    file_path = os.path.join('3_IBI-CGFF', '3_IBI_pot', filename)
    table.set_from_file(type1, type2, filename=file_path)

# 加载键作用势能
btable = bond.table(width=24000)
for bond_type, filename in bond_potentials.items():
    file_path = os.path.join('3_IBI-CGFF', '3_IBI_pot', filename)
    btable.set_from_file(bond_type, filename=file_path)

# 加载角度作用势能
atable = angle.table(width=2001)
for angle_type, filename in angle_potentials.items():
    file_path = os.path.join('3_IBI-CGFF', '3_IBI_pot', filename)
    atable.set_from_file(angle_type, filename=file_path)

# 加载二面角作用势能
dtable = dihedral.table(width=2001)
for dihedral_type, filename in dihedral_potentials.items():
    file_path = os.path.join('3_IBI-CGFF', '3_IBI_pot', filename)
    dtable.set_from_file(dihedral_type, filename=file_path)


nlist.set_params(r_buff = 0.1, check_period = 1)
nlist.reset_exclusions(exclusions = ['bond', 'angle','dihedral'])

all = group.all()

integrate.mode_standard(dt=0.001)
integrate.nvt(group=all, T=583 / 120.27236,tau=0.5)
#integrate.npt(group=all, T=583 / 120.27236,tau=0.5,P=0.061,tauP=5.0)
#nve = integrate.nve_rigid(group=all.rigid())
zeroer= update.zero_momentum(period=10000)

# reaction sect. #
from scipy.spatial import cKDTree
import numpy as np
import numba as nb

@nb.jit(nopython=True, nogil=True)
def pbc(r, d):
    x = r - d * np.rint(r / d)
    return np.sum(x*x)

rc = 0.79
rmin = 0.53

bonds_new = set()
mx_ro = {'A': 2, 'B': 1, 'C': 1}
particle_ro = np.zeros(len(s.particles))
#r_stat = np.ones(len(s.particles))
bond_hash = {}
for i in range(len(s.particles)):
    bond_hash[i] = set()
for b_ in s.bonds:
    if 'A' in b_.type:
        particle_ro[b_.a] += 1
        particle_ro[b_.b] += 1
    bond_hash[b_.a].add(b_.b)
    bond_hash[b_.b].add(b_.a)


angle_hash = {}  # exclusions
diheral_hash = {}

import time

def reaction(ts):
    s_ = time.time()
    a = s.take_snapshot()
    box = np.array([a.box.Lx, a.box.Ly, a.box.Lz])
    # marking reacting beads
    type_idx_hash = {}
    for t in s.particles.types:
        type_idx_hash[t] = []
    for i, p in enumerate(s.particles):
        if p.type == 'S': continue
        mr = max_ro[p.type]
        if particle_ro[i] < mr:
            type_idx_hash[p.type].append(i)
    for k in type_idx_hash:
        type_idx_hash[k] = np.asarray(type_idx_hash[k], dtype=np.int64)
    # end

    pa = a.particles.position[type_idx_hash['A']]
    print("%d A left, %d have order 0 and %d have order 1" % (pa.shape[0], np.sum(particle_ro[type_idx_hash['A']]==0), np.sum(particle_ro[type_idx_hash['A']]==1)))
    #x_ = np.argwhere(particle_ro == 0).ravel()
    #y_ = x_[np.in1d(x_, type_idx_hash['A'])]
    #print(y_,bond_hash[y_[0]])
    pb = a.particles.position[type_idx_hash['B']]
    pc = a.particles.position[type_idx_hash['C']]
    if pa.shape[0] < 1 or pb.shape[0] < 1 or pc.shape[0] < 1:
        return
    
    treeb = cKDTree(np.mod(pb, box), boxsize=box[0])
    treec = cKDTree(np.mod(pc, box), boxsize=box[0])
    n_ab = treeb.query_ball_point(np.mod(pa, box), rc)
    n_ac = treec.query_ball_point(np.mod(pa, box), rc)#, workers=-1)
    #print(n_ab[y_[0]], n_ac[y_[0]])
    for i, nb_ in enumerate(n_ab):
        xa = pa[i] # position of A, no need of positions yet
        idx_a = type_idx_hash['A'][i]
        idc_b = type_idx_hash['B'][nb_]
        #r_stat_a = r_stat[idx_a]
        a_ro = particle_ro[idx_a]
        for idx_b in idc_b:
            rij = pbc(xa - a.particles.position[idx_b], box)
            if rij < rmin ** 2:
                continue
            allowed = True
            for nbra in bond_hash[idx_a]:
                if idx_b == nbra or idx_b in bond_hash[nbra]:
                    allowed = False
            for nbrb in bond_hash[idx_b]:
                if idx_a == nbrb or idx_a in bond_hash[nbrb]:
                    allowed = False
            if not allowed:
                continue
            if particle_ro[idx_a] >= max_ro['A']:
                continue
            if particle_ro[idx_b] >= max_ro['B']:
                continue
            #if idx_b in angle_hash[idx_a]:
            #    continue
            #if idx_b in diheral_hash[idx_a]:
            #    continue
            #r_stat_b = r_stat[idx_b]
            if a_ro == 0:
                p = 0.9
            if a_ro == 1:
                p = 0.01
            rn = np.random.random()
            if rn < p:
                particle_ro[idx_a] += 1
                particle_ro[idx_b] += 1
                bond_hash[idx_a].add(idx_b)
                bond_hash[idx_b].add(idx_a)
                s.bonds.add('A-B', int(idx_a), int(idx_b))
                for nbra in bond_hash[idx_a]:
                    if nbra == idx_b:
                        continue
                    name_ = '%s-A-B' % s.particles[int(nbra)].type
                    if name_ == 'C-A-B':
                        name_ = 'B-A-B'
                    s.angles.add(name_, int(nbra), int(idx_a), int(idx_b))
                    for nbraa in bond_hash[nbra]:
                        if nbraa == idx_a:
                            continue
                        name_ = '%s-%s-A-B' % (s.particles[int(nbra)].type, s.particles[int(nbraa)].type)
                        if name_ == 'C-B-A-B':
                            name_ = 'B-A-B-C'
                        s.dihedrals.add(name_, int(nbraa), int(nbra), int(idx_a), int(idx_b))
                for nbrb in bond_hash[idx_b]:
                    if nbrb == idx_a:
                        continue
                    s.angles.add('A-B-%s' % s.particles[int(nbrb)].type, int(idx_a), int(idx_b), int(nbrb))
                    for nbrbb in bond_hash[nbrb]:
                        if nbrbb == idx_b:
                            continue
                        s.dihedrals.add('A-B-%s-%s' % (s.particles[int(nbrb)].type, s.particles[int(nbrbb)].type), int(idx_a), int(idx_b), int(nbrb), int(nbrbb))
                for nbra in bond_hash[idx_a]:
                    if nbra == idx_b:
                        continue
                    for nbrb in bond_hash[idx_b]:
                        if nbrb == idx_a:
                            continue
                        name_ = '%s-A-B-%s' % (s.particles[int(nbra)].type, s.particles[int(nbrb)].type)
                        s.dihedrals.add(name_, int(nbra), int(idx_a), int(idx_b), int(nbrb))
                break

    for i, nc_ in enumerate(n_ac):
        xa = pa[i] # position of A, no need of positions yet
        idx_a = type_idx_hash['A'][i]
        idc_c = type_idx_hash['C'][nc_]
        #r_stat_a = r_stat[idx_a]
        a_ro = particle_ro[idx_a]
        for idx_c in idc_c:
            rij = pbc(xa - a.particles.position[idx_c], box)
            if rij < rmin ** 2:
                continue
            allowed = True
            for nbra in bond_hash[idx_a]:
                if idx_c == nbra or idx_c in bond_hash[nbra]:
                    allowed = False
            for nbrc in bond_hash[idx_c]:
                if idx_a == nbrc or idx_a in bond_hash[nbrc]:
                    allowed = False
            if not allowed:
                continue
            if particle_ro[idx_a] >= max_ro['A']:
                continue
            if particle_ro[idx_c] >= max_ro['C']:
                continue
            if idx_c in bond_hash[idx_a]:
                continue
            if idx_a in bond_hash[idx_c]:
                continue
            #if idx_c in angle_hash[idx_a]:
            #    continue
            #if idx_c in diheral_hash[idx_a]:
            #    continue
            #r_stat_b = r_stat[idx_b]
            if a_ro == 0:
                p = 0.9
            if a_ro == 1:
                p = 0.01
            rn = np.random.random()
            if rn < p:
                particle_ro[idx_a] += 1
                particle_ro[idx_c] += 1
                bond_hash[idx_a].add(idx_c)
                bond_hash[idx_c].add(idx_a)
                s.bonds.add('A-C', int(idx_a), int(idx_c))
                for nbra in bond_hash[idx_a]:
                    if nbra == idx_c:
                        continue
                    s.angles.add('%s-A-C' % s.particles[int(nbra)].type, int(nbra), int(idx_a), int(idx_c))
                    for nbraa in bond_hash[nbra]:
                        if nbraa == idx_a:
                            continue
                        name_ = '%s-%s-A-C' % (s.particles[int(nbra)].type, s.particles[int(nbraa)].type)
                        if name_ == 'C-B-A-C':
                            name_ = 'B-C-A-C'
                        s.dihedrals.add(name_, int(nbraa), int(nbra), int(idx_a), int(idx_c))
                for nbrc in bond_hash[idx_c]:
                    if nbrc == idx_a:
                        continue
                    s.angles.add('A-C-%s' % s.particles[int(nbrc)].type, int(idx_a), int(idx_c), int(nbrc))
                    for nbrcc in bond_hash[nbrc]:
                        if nbrcc == idx_c:
                            continue
                        s.dihedrals.add('A-C-%s-%s' % (s.particles[int(nbrc)].type, s.particles[int(nbrcc)].type), int(idx_a), int(idx_c), int(nbrc), int(nbrcc))
                for nbra in bond_hash[idx_a]:
                    if nbra == idx_c:
                        continue
                    for nbrc in bond_hash[idx_c]:
                        if nbrc == idx_a:
                            continue
                        name_ = '%s-A-C-%s' % (s.particles[int(nbra)].type, s.particles[nbrc].type)
                        if name_ == 'C-A-C-B':
                            name_ = 'B-C-A-C'
                        if name_ == 'B-A-C-B':
                            name_ = 'B-C-A-B'
                        s.dihedrals.add(name_, int(nbra), int(idx_a), int(idx_c), int(nbrc))
                break
    print("%.6fs" % (time.time()-s_))

##################
#      end       #
##################


xml = dump.xml(filename="r-nvt-210du-20ns", period=1e6)
xml.set_params(position=True, body=True,type=True, image=True, bond=True, angle=True,dihedral=True,mass=True,velocity=True)
sorter.set_period(100)
analyze.log(filename='pressure.log',quantities=['pressure'],period=1000, header_prefix='#',overwrite=False)
analyze.log(filename='temperature.log', quantities=['temperature'], period=5000, phase=0)
log = analyze.log(filename=None, quantities=['potential_energy'], period=1)
U = log.query('potential_energy')

#pre = analyze.log(filename='pre.log', quantities=['volume','pressure','pressure_xx','pressure_yy','pressure_zz','pressure_xy', 'pressure_xz', 'pressure_yz'], header_prefix='#', period=10000, overwrite=True)
analyze.callback(callback=reaction, period=1e4)
#run(int(1e6))
run(20e6+1)
