import numpy as np
import os

# 常数
K_B = 1.380649e-23  # 玻尔兹曼常数 (J/K)
H = 6.62607015e-34  # 普朗克常数 (J·s)
R = 8.314462618  # 气体常数 (J/(mol·K))
P0 = 101325  # 标准大气压 (Pa)
KCAL_TO_KJ = 4.184  # kcal 转换为 kJ

def read_energy_barrier(filename):
    """从文件中读取反应能垒 (kcal/mol)，并转换为 kJ/mol."""
    if not os.path.exists(filename):
        print(f"错误: 文件 '{filename}' 不存在。")
        return None

    try:
        with open(filename, 'r') as file:
            energy_barrier_kcal = float(file.readline().strip())
            # 转换为 kJ/mol
            return energy_barrier_kcal * KCAL_TO_KJ
    except ValueError:
        print(f"错误: 文件 '{filename}' 中的反应能垒格式不正确。")
        return None

def calculate_rate_constant(sigma, T, delta_n, energy_barrier):
    """
    根据过渡态理论计算反应速率常数 k (单位: s^-1 L mol^-1)。

    参数:
    - sigma: 反应路径简并度
    - T: 温度 (K)
    - delta_n: 反应分子数的变化
    - energy_barrier: 活化能 (kJ/mol)

    返回:
    - 反应速率常数 k (s^-1 L mol^-1)
    """
    # 计算速率常数
    pre_factor = sigma * (K_B * T / H) * (R * T / P0) ** delta_n
    rate_constant = pre_factor * np.exp(-energy_barrier * 1000 / (K_B * T))  # kJ/mol 转换为 J/mol
    return rate_constant / 1000  # 转换单位为 s^-1 L mol^-1

def main():
    """主函数：计算多个反应的速率常数并保存结果。"""
    try:
        n_reactions = int(input("请输入需要计算的反应数量: "))
    except ValueError:
        print("错误: 请输入有效的整数作为反应数量。")
        return

    for i in range(1, n_reactions + 1):
        print(f"\n--- 计算第 {i} 次反应 ---")

        # 读取能垒文件路径
        energy_barrier_filename = os.path.join("..", "1_DFT_cal_energy_barrier", f"{i}_th_energy_barrier.txt")
        delta_G_ne = read_energy_barrier(energy_barrier_filename)  # 读取活化吉布斯自由能
        if delta_G_ne is None:
            print(f"跳过第 {i} 次反应的计算。")
            continue

        try:
            sigma = float(input("请输入反应路径简并度 σ: "))
            T = float(input("请输入反应温度 (K): "))
            delta_n = 1  # 假设为双分子反应
        except ValueError:
            print("错误: 请输入有效的浮点数。")
            continue

        # 计算反应速率常数
        rate_constant = calculate_rate_constant(sigma, T, delta_n, delta_G_ne)
        print(f"计算得到的反应速率常数 k 为: {rate_constant:.6e} s^-1 L mol^-1")

        # 保存结果到文件
        result_filename = f"{i}_th_k.txt"
        try:
            with open(result_filename, 'w') as f:
                f.write(f"{rate_constant:.6e}\n")
            print(f"反应速率常数已保存至 {result_filename}")
        except IOError as e:
            print(f"保存结果时发生错误: {e}")

if __name__ == "__main__":
    main()


