# -*- coding: utf-8 -*-

import numpy as np
from io import StringIO
from xml.etree import cElementTree  # pypy会比python稍慢
from pandas import read_csv
import sys

sys.dont_write_bytecode = True

class HoomdXml:
    """
    解析HOOMD XML文件，提取粒子和键的信息。
    """
    
    @staticmethod
    def _get_attrib(dd):
        """
        从字典中获取属性，并返回NumPy数组。
        
        :param dd: 包含属性的字典
        :return: NumPy数组
        """
        dt = eval('[' + ','.join(["('%s', int)" % key for key in dd.keys()]) + ']')
        values = [tuple(dd.values())]
        return np.array(values, dtype=dt)

    def __init__(self, filename, needed=[]):
        """
        初始化HoomdXml实例，读取XML文件并解析所需属性。
        
        :param filename: XML文件路径
        :param needed: 需要解析的属性列表
        """
        self.nodes = {}
        self._parse_xml(filename, needed)

    def _parse_xml(self, filename, needed):
        """
        解析给定的XML文件，提取配置和节点信息。
        
        :param filename: XML文件路径
        :param needed: 需要解析的属性列表
        """
        tree = cElementTree.ElementTree(file=filename)
        root = tree.getroot()
        configuration = root[0]
        self.configure = self._get_attrib(configuration.attrib)

        for e in configuration:
            if e.tag == 'box':
                self.box = np.array([float(e.attrib['lx']),
                                     float(e.attrib['ly']),
                                     float(e.attrib['lz'])])
                continue
            if len(needed) != 0 and e.tag not in needed:
                continue
            self.nodes[e.tag] = read_csv(StringIO(e.text), delim_whitespace=True, squeeze=1, header=None).values


def bond_hash_dualdirect(bond, natoms):
    """
    创建双向的键哈希表，用于快速查找分子之间的连接关系。
    
    :param bond: 键数据，格式为 (name, id1, id2)
    :param natoms: 粒子总数
    :return: bond_hash_nn（邻接列表）和 bond_hash_wn（权重字典）
    """
    bond_hash_wn = {i: {} for i in range(natoms)}
    bond_hash_nn = {i: [] for i in range(natoms)}
    
    for b in bond:
        nm, idx, jdx = b[0], int(b[1]), int(b[2])
        bond_hash_wn[idx][jdx] = nm
        bond_hash_nn[idx].append(jdx)
        bond_hash_nn[jdx].append(idx)
        bond_hash_wn[jdx][idx] = nm

    return bond_hash_nn, bond_hash_wn


def grab_iter(i, bond_hash, mol_used, body_hash=None):
    """
    使用深度优先搜索方法获取与给定原子相连的分子列表。
    
    :param i: 起始原子的索引
    :param bond_hash: 键哈希表
    :param mol_used: 分子使用状态的字典
    :param body_hash: 体连接哈希表（可选）
    :return: 连接的分子索引列表
    """
    S = [i]  # Stack for DFS
    R = []   # Result list of connected molecules
    
    while S:
        v = S.pop()
        if not mol_used[v]:
            R.append(v)
            mol_used[v] = True
            S.extend(bond_hash[v])
            if body_hash:
                for w in body_hash[v]:
                    S.append(w)
                    S.extend(bond_hash[w])
    return R


def get_mol_idxes(natoms, bond_hash, body_hash=None):
    """
    获取分子的索引列表，返回所有独立的分子。
    
    :param natoms: 粒子总数
    :param bond_hash: 键哈希表
    :param body_hash: 体连接哈希表（可选）
    :return: 包含分子索引的NumPy数组
    """
    molecular_hash = {i: False for i in range(natoms)}
    molecular_list = []

    for i in range(natoms):
        molecular_idxs = grab_iter(i, bond_hash, mol_used=molecular_hash, body_hash=body_hash)
        if len(molecular_idxs) != 1:  # 仅将非单一原子的分子添加到列表中
            molecular_list.append(molecular_idxs)
        for atom in molecular_idxs:
            molecular_hash[atom] = True

    # 移除空的分子列表
    molecular_list = [molecular for molecular in molecular_list if molecular]
    return np.array([np.array(x) for x in molecular_list])


