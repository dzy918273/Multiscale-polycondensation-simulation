# -*- coding: utf-8 -*-
"""
计算聚合物的加权平均分子量 (Mw)、数均分子量 (Mn) 及分子量分布指数 (PDI)。
"""

import numpy as np
import pandas as pd
from sys import argv
from XmlBuilder import hoomd_xml, bond_hash_dualdirect, get_mol_idxes

def load_xml_data(xml_file):
    """从XML文件中加载数据，包括原子类型、键信息和质量。

    Args:
        xml_file (str): XML文件的路径。

    Returns:
        tuple: 原子类型数组、原子数量、键信息数组。
    """
    xml = hoomd_xml(xml_file, needed=['type', 'bond', 'mass'])
    types = xml.nodes["type"]
    types = types[types != 'S']  # 排除类型为'S'的原子
    natoms = len(types)
    bond_info = xml.nodes["bond"]
    bond_info = bond_info[bond_info[:, 0] != 'S-S']  # 排除'S-S'的键
    return types, natoms, bond_info

def calculate_bond_hash(bond_info, natoms):
    """计算双向键的哈希值。

    Args:
        bond_info (np.ndarray): 键信息数组。
        natoms (int): 原子数量。

    Returns:
        tuple: 最近邻键哈希和全键哈希。
    """
    return bond_hash_dualdirect(bond_info, natoms)

def get_molecular_weights(types):
    """根据原子类型获取分子量。

    Args:
        types (np.ndarray): 原子类型数组。

    Returns:
        np.ndarray: 每种原子的分子量数组。
    """
    mass_by_type = {"A": 108, "B": 90, "C": 90}  # 原子类型与分子量的对应关系
    mass = np.array([mass_by_type[t] for t in types])
    return mass

def calculate_molecular_properties(mol_index, mass, natoms):
    """计算Mw、Mn和PDI。

    Args:
        mol_index (list): 分子的索引列表。
        mass (np.ndarray): 原子的分子量数组。
        natoms (int): 原子数量。

    Returns:
        tuple: Mw、Mn和PDI值。
    """
    len_mol_fre = np.array([len(mol) for mol in mol_index])
    Mw = 0
    Mn = 0

    for i, mol in enumerate(mol_index):
        mol_fraction = len_mol_fre[i] / natoms
        mol_mass = mass[mol]
        Mw += (mol_mass.sum() ** 2) * mol_fraction
        Mn += mol_mass.sum() * mol_fraction

    Mw = Mw / Mn
    PDI = Mw / Mn
    return Mw, Mn, PDI

def save_distribution(len_mol_fre):
    """将分子量分布保存为CSV文件。

    Args:
        len_mol_fre (np.ndarray): 分子的长度数组。
    """
    denominator = len(len_mol_fre)
    Data = pd.Series(len_mol_fre)
    Fre = Data.value_counts()
    Fre_sort = Fre.sort_index(ascending=True)
    DF = Fre_sort.reset_index()
    DF[0] = DF[0] / denominator
    DF = DF[DF[0] != 0]
    DF.to_csv('PDI.txt', index=False, header=None, sep=' ')

def main():
    if len(argv) != 2:
        print("用法: python PDI.py <XML文件路径>")
        return

    # 加载数据
    types, natoms, bond_info = load_xml_data(argv[1])

    # 计算键的哈希值和分子索引
    bond_hash_nn, _ = calculate_bond_hash(bond_info, natoms)
    mol_index = get_mol_idxes(natoms, bond_hash_nn)

    # 获取原子分子量
    mass = get_molecular_weights(types)

    # 计算Mw、Mn和PDI
    Mw, Mn, PDI = calculate_molecular_properties(mol_index, mass, natoms)

    # 保存分子量分布
    len_mol_fre = np.array([len(mol) for mol in mol_index])
    save_distribution(len_mol_fre)

    # 打印结果
    print("Mw is %.3f, Mn is %.3f, PDI is %.6f" % (Mw, Mn, PDI))

if __name__ == "__main__":
    main()


