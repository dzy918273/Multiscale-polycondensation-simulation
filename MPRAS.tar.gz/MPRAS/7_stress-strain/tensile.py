import numpy as np
import pandas as pd
import sys

# 定义读取数据的函数
def read_data(file_path):
    """从指定路径读取数据，返回DataFrame"""
    try:
        data = pd.read_csv(file_path, delim_whitespace=True)
        print(f"成功读取数据文件: {file_path}")
        return data
    except Exception as e:
        print(f"读取数据文件时出错: {e}")
        sys.exit(1)

# 计算应力的函数
def calculate_stress(data):
    """计算应力"""
    pxx = data['press_xx'].values
    pyy = data['press_yy'].values
    pzz = data['press_zz'].values

    # 计算水压作为应力的参考
    hydrostatic_pressure = (pxx + pyy + pzz) / 3
    stress = -pzz  # 应力计算公式
    return stress, hydrostatic_pressure

# 计算应变的函数
def calculate_tensile_strain(lz):
    """计算拉伸应变"""
    init_lz = lz[0]
    tensile_strain = (lz - init_lz) / init_lz
    return tensile_strain

# 保存结果到文件的函数
def save_results(tensile_strain, stress, output_file):
    """将应变和应力数据保存到文本文件"""
    try:
        np.savetxt(output_file, np.c_[tensile_strain, stress], fmt='%.6f')
        print(f"结果已保存到文件: {output_file}")
    except Exception as e:
        print(f"保存结果时出错: {e}")
        sys.exit(1)

# 主程序函数
def main(file_path):
    """主程序逻辑"""
    # 读取数据
    data = read_data(file_path)

    # 提取长度数据
    lz = data['Lz'].values

    # 计算应力
    stress, hydrostatic_pressure = calculate_stress(data)

    # 计算应变
    tensile_strain = calculate_tensile_strain(lz)

    # 保存结果
    save_results(tensile_strain, stress, 'stress-strain.txt')

# 入口点
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("用法: python tensile.py <数据文件路径>")
        sys.exit(1)

    input_file_path = sys.argv[1]
    main(input_file_path)

