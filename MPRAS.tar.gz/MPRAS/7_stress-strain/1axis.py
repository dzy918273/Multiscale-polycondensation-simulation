#!/usr/bin/python
from sys import argv
import sys
import os
sys.path.append('/opt/galamost/z-setup/lib')
import galamost
from optparse import OptionParser

def parse_options():
    """解析命令行选项"""
    parser = OptionParser()
    parser.add_option('--gpu', dest='gpu', help='GPU on which to execute')
    (options, args) = parser.parse_args()
    return options, args

def load_potential_files(folder_path):
    """加载力场文件"""
    potential_files = {}
    try:
        for file_name in os.listdir(folder_path):
            if file_name.endswith('.log'):  # 只加载以 .log 结尾的力场文件
                potential_files[file_name] = os.path.join(folder_path, file_name)
    except FileNotFoundError:
        print(f"无法找到力场文件夹：{folder_path}")
        sys.exit(1)
    return potential_files

def initialize_simulation(filename, gpu):
    """初始化模拟设置"""
    try:
        build_method = galamost.XmlReader(filename)
        perform_config = galamost.PerformConfig(gpu)
        all_info = galamost.AllInfo(build_method, perform_config)
        return all_info
    except Exception as e:
        print(f"初始化失败: {e}")
        sys.exit(1)

def setup_forces(all_info, potential_files):
    """设置力场"""
    # 创建邻居列表
    neighbor_list = galamost.NeighborList(all_info, 2.5, 0.1)
    neighbor_list.addExclusionsFromBonds()
    neighbor_list.addExclusionsFromAngles()
    neighbor_list.addExclusionsFromDihedrals()

    pair = galamost.PairForceTable(all_info, neighbor_list, 2000)
    pair.setPotential('A', 'A', potential_files.get("nb-AA.log"), 0, 1)
    pair.setPotential('A', 'B', potential_files.get("nb-AB.log"), 0, 1)
    pair.setPotential('A', 'C', potential_files.get("nb-AC.log"), 0, 1)
    pair.setPotential('B', 'B', potential_files.get("nb-BB.log"), 0, 1)
    pair.setPotential('B', 'C', potential_files.get("nb-BC.log"), 0, 1)
    pair.setPotential('C', 'C', potential_files.get("nb-CC.log"), 0, 1)

    bond = galamost.BondForceTable(all_info, 24000)
    bond.setPotential('A-B', potential_files.get("b-AB-1-CG.log"), 0, 1)
    bond.setPotential('B-C', potential_files.get("b-BC-1-CG.log"), 0, 1)
    bond.setPotential('A-C', potential_files.get("b-AC-1-CG.log"), 0, 1)

    angle = galamost.AngleForceTable(all_info, 2000)
    angle.setPotential('A-B-C', potential_files.get("a-ABC-1-CG.log"), 0, 1)
    angle.setPotential('A-C-B', potential_files.get("a-ACB-1-CG.log"), 0, 1)
    angle.setPotential('B-A-C', potential_files.get("a-BAC-1-CG.log"), 0, 1)

    dihedral = galamost.DihedralForceTable(all_info, 2001)
    dihedral.setPotential('A-B-C-A', potential_files.get("d-ABCA-1-CG.log"), 0, 1)
    dihedral.setPotential('B-A-C-B', potential_files.get("d-BACB-1-CG.log"), 0, 1)

    return pair, bond, angle, dihedral

def main():
    options, args = parse_options()
    filename = 'output_file.xml'  # 从4_CG-reation生成的输出文件

    # 加载力场文件
    potential_files = load_potential_files('./3_IBI-CGFF/')  # 假设力场文件在3_IBI-CGFF文件夹内

    # 初始化模拟
    all_info = initialize_simulation(filename, options.gpu)

    # 设置力场
    pair, bond, angle, dihedral = setup_forces(all_info, potential_files)

    # 计算和排序设置
    group = galamost.ParticleSet(all_info, 'all')
    comp_info = galamost.ComputeInfo(all_info, group)
    sort_method = galamost.Sort(all_info)
    sort_method.setPeriod(10000)

    # 零动量设置
    zm = galamost.ZeroMomentum(all_info)
    zm.setPeriod(10000)

    # 温度和压力设置
    Temperature = 300  # K
    T = Temperature / 120.27236  # 归一化温度
    P = 0.0610  # 压力

    # 使用Berendsen NVT
    nvt = galamost.BerendsenNvt(all_info, group, comp_info, T, 0.5)

    # 日志信息设置
    dinfo = galamost.DumpInfo(all_info, comp_info, 'data.log')
    dinfo.setPeriod(100000)

    # 设置盒子长度
    lx = all_info.getBasicInfo().getGlobalBox().getL().x
    ly = all_info.getBasicInfo().getGlobalBox().getL().y
    lz = all_info.getBasicInfo().getGlobalBox().getL().z

    step = int(2e6)  # 2 million steps
    t = 0

    # 重启设置
    restart = galamost.XmlDump(all_info, 'restart')
    restart.setPeriod(int(1e4))
    restart.setOutputPosition(True)
    restart.setOutputMass(True)
    restart.setOutputType(True)
    restart.setOutputImage(True)
    restart.setOutputBond(True)
    restart.setOutputAngle(True)
    restart.setOutputDihedral(True)

    # 执行三轴拉伸模拟
    for i in range(1):
        # 运行拉伸
        t = apply_stretching(all_info, group, step, t, direction='Z')

        # 设置卸载阶段
        v = galamost.VariantLinear()
        v.setPoint(t, 2.0)  # 拉伸结束盒子长度
        v.setPoint(t + step, 1.0)  # 卸载时盒子长度恢复
        
        axs = galamost.AxialStretching(all_info, group)
        axs.setBoxLength(v, 'Z')
        axs.setPeriod(10)
        
        # 添加到卸载应用
        unload = galamost.Application(all_info, 0.002)
        unload.add(pair)
        unload.add(bond)
        unload.add(angle)
        unload.add(dihedral)
        unload.add(sort_method)
        unload.add(zm)
        unload.add(dinfo)
        unload.add(axs)
        unload.add(nvt)
        unload.add(restart)
        
        # 执行卸载
        unload.run(step)
        t += step

if __name__ == "__main__":
    main()


